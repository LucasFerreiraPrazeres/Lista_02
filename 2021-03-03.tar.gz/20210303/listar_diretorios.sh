#!/bin/bash



read -p "digite um diretorio:" diretorio01
ls ${diretorio01}

read -p "digite um diretorio:" diretorio02
ls ${diretorio02}

read -p "digite um diretorio:" diretorio03
ls ${diretorio03}


