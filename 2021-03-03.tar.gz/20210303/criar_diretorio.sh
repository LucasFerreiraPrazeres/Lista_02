#!/bin/bash


mkdir /tmp/`date +%Y%m%d`

cp ./* /tmp/20210303


