# Lista_02
Lista 02 - Primeiros passos com bash
