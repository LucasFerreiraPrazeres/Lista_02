#!/bin/bash
echo "SIMBORA MEU CHEFE!!!"
